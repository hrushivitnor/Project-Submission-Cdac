import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Buyers } from '../buyer';
import { BuyerserviceService } from '../buyerservice.service';

@Component({
  selector: 'app-addbuyer',
  templateUrl: './addbuyer.component.html',
  styleUrls: ['./addbuyer.component.css']
})
export class AddbuyerComponent implements OnInit {
  buyer: Buyers = new Buyers();
  submitted 
  constructor(private _service:BuyerserviceService,private router:Router) { }

  ngOnInit(): void {
  }

  saveBuyer() {
    this._service.createBuyer(this.buyer)
      .subscribe(data => console.log(data), error => console.log(error));
    this.buyer = new Buyers();
    this.gotoBuyerList();
  }

  onSubmit() {
    this.saveBuyer();    
  }

  gotoBuyerList() {
    this.router.navigate(['/buyers']);
  }

}


