import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddproducerComponent } from './addproducer.component';

describe('AddproducerComponent', () => {
  let component: AddproducerComponent;
  let fixture: ComponentFixture<AddproducerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddproducerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddproducerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
