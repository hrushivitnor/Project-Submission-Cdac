import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Producer } from '../producer';
import { ProducerserviceService } from '../producerservice.service';

@Component({
  selector: 'app-addproducer',
  templateUrl: './addproducer.component.html',
  styleUrls: ['./addproducer.component.css']
})
export class AddproducerComponent implements OnInit {
  producer: Producer = new Producer();
  submitted 
  constructor(private _service:ProducerserviceService,private router:Router) { }

  ngOnInit(): void {
  }

  saveProducer() {
    this._service.createProducer(this.producer)
      .subscribe(data => console.log(data), error => console.log(error));
    this.producer = new Producer();
    this.gotoProducerList();
  }

  onSubmit() {
    this.saveProducer();    
  }

  gotoProducerList() {
    this.router.navigate(['/producers']);
  }

}