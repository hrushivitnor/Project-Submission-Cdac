export class Admin{
    user_id:number;
	role:string;
	firstName:string ;
	lastName:string;
	email:string;
	contact_no:number=10;
	password:string;
	account_balance:number;
} 