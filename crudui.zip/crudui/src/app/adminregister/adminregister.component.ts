import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';


@Component({
  selector: 'app-adminregister',
  templateUrl: './adminregister.component.html',
  styleUrls: ['./adminregister.component.css']
})
export class AdminregisterComponent implements OnInit {

  admin: Admin = new Admin();
  constructor(private adminService:AdminService,
    private router:Router) { }
    
    saveAdmin(){
      this.admin.role="admin";
      this.admin.account_balance=10000;
this.adminService.createAdmin(this.admin).subscribe(data =>{
  console.log(data);
  this.goToAdmin();
},
error => console.log(error))};

goToAdmin(){
  this.router.navigate(['/admin'])
}
  ngOnInit(): void {
  }
  onSubmit(){
    console.log(this.admin);
    this.saveAdmin();
  }
}
