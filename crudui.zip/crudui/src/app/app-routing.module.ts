import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddbuyerComponent } from './addbuyer/addbuyer.component';
import { BuyerlistComponent } from './buyerlist/buyerlist.component';
import { EditbuyerComponent } from './editbuyer/editbuyer.component';
import { ViewbuyerComponent } from './viewbuyer/viewbuyer.component';
import { UpdatebuyerComponent } from './updatebuyer/updatebuyer.component';
import { AddproducerComponent} from './addproducer/addproducer.component';
import {ProducerlistComponent} from './producerlist/producerlist.component';
import{EditproducerComponent} from './editproducer/editproducer.component';
import{ViewproducerComponent} from './viewproducer/viewproducer.component';
import{UpdateproducerComponent} from './updateproducer/updateproducer.component';
import { LoginComponent } from './login/login.component';
import { RegisteropComponent } from './registerop/registerop.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminregisterComponent } from './adminregister/adminregister.component';
import { ProducerregisterComponent } from './producerregister/producerregister.component';
import { AdminComponent } from './admin/admin.component';
import { BuyerregisterComponent } from './buyerregister/buyerregister.component';

const routes: Routes = [
  {path:'',component:BuyerlistComponent},
  {path:'addbuyer',component:AddbuyerComponent},
  {path :'buyers' ,component:BuyerlistComponent},
  {path:'viewbuyer/:bid',component:ViewbuyerComponent},
  {path:'update',component:EditbuyerComponent},
  {path: 'updatbuyer',component:UpdatebuyerComponent},
  {path:'',component:ProducerlistComponent},
  {path:'addproducer',component:AddproducerComponent},
  {path:'producer',component:ProducerlistComponent},
  {path:'update',component:EditproducerComponent},
  {path:'viewproducer/:pid',component:ViewproducerComponent},
  {path:'Updateproducer',component:UpdateproducerComponent},
  {path:'login',component:LoginComponent},
  {path:'registerop',component: RegisteropComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'radmin',component:AdminregisterComponent},
   {path:'admin',component:AdminComponent},
   {path:'rproducer',component:ProducerregisterComponent},
   {path:'rbuyer',component:BuyerregisterComponent}
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
