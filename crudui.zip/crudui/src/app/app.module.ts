import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BuyerlistComponent } from './buyerlist/buyerlist.component';
import { EditbuyerComponent } from './editbuyer/editbuyer.component';
import { ViewbuyerComponent } from './viewbuyer/viewbuyer.component';
import { HttpClientModule } from '@angular/common/http';
import { AddbuyerComponent } from './addbuyer/addbuyer.component';
import { FormsModule } from '@angular/forms';
import { UpdatebuyerComponent } from './updatebuyer/updatebuyer.component';
import { AddproducerComponent } from './addproducer/addproducer.component';
import { ProducerlistComponent } from './producerlist/producerlist.component';
import { EditproducerComponent } from './editproducer/editproducer.component';
import { UpdateproducerComponent } from './updateproducer/updateproducer.component';
import { ViewproducerComponent } from './viewproducer/viewproducer.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AdminComponent } from './admin/admin.component';
import { AdminregisterComponent } from './adminregister/adminregister.component';
import { BuyerregisterComponent } from './buyerregister/buyerregister.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LoginsuccessComponent } from './loginsuccess/loginsuccess.component';
import { NavbarComponent } from './navbar/navbar.component';
import { PownerComponent } from './powner/powner.component';
import { ProducerComponent } from './producer/producer.component';
import { ProducerregisterComponent } from './producerregister/producerregister.component';
import { RegisteropComponent } from './registerop/registerop.component';

@NgModule({
  declarations: [
    AppComponent,
    BuyerlistComponent,
    EditbuyerComponent,
    ViewbuyerComponent,
    AddbuyerComponent,
    UpdatebuyerComponent,
    AddproducerComponent,
    ProducerlistComponent,
    EditproducerComponent,
    UpdateproducerComponent,
    ViewproducerComponent,
    AboutusComponent,
    AdminComponent,
    AdminregisterComponent,
    BuyerregisterComponent,
    HomeComponent,
    LoginComponent,
    LoginsuccessComponent,
    NavbarComponent,
    PownerComponent,
    ProducerComponent,
    ProducerregisterComponent,
    RegisteropComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
