export class Buyers {

    bid:number;

         bname:String ;

       emailId:String;

        address:String;
         district:String;
          city:String;

          pincode:number;
          state:String;

         contactNo:number;
           accountNo:number;

          aadharNo:number;
        licenceType:String;

        ubin:number;
        cropPrice:number;
        cropname:string;
        crops:[];
    }
