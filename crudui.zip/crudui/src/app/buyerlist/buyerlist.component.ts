import { Component, OnInit } from '@angular/core';
import { Buyers } from '../buyer';
import { BuyerserviceService } from '../buyerservice.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
@Component({
  selector: 'app-buyerlist',
  templateUrl: './buyerlist.component.html',
  styleUrls: ['./buyerlist.component.css']
})
export class BuyerlistComponent implements OnInit {
  buyers: Observable<Buyers[]>;
  constructor(private _service:BuyerserviceService, private router: Router) { }

  ngOnInit(): void {
                        this.fetchBuyerList();
                                                             
                       }

                       fetchBuyerList() {
                        this.buyers = this._service.getBuyerList();
                      }


                      deleteBuyer(bid: number) {
                        this._service.deleteBuyer(bid)
                          .subscribe(
                            data => {
                              console.log(data);
                              this.fetchBuyerList();
                            },
                            error => console.log(error));
                      }
                    
                    BuyerDetailsByID(bid: number) {
                        this.router.navigate(['viewbuyer', bid]);
                      }
                    
                      updateBuyer(buyer: Buyers){
                        this.router.navigate(['update', buyer]);
                      }    
                      
                      CreateBuyer()
                      {
                        this.router.navigate(['/addbuyer']);
                      }
                    
}
