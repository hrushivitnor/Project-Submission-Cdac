import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyerregisterComponent } from './buyerregister.component';

describe('BuyerregisterComponent', () => {
  let component: BuyerregisterComponent;
  let fixture: ComponentFixture<BuyerregisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuyerregisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyerregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
