import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyerregister',
  templateUrl: './buyerregister.component.html',
  styleUrls: ['./buyerregister.component.css']
})
export class BuyerregisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
