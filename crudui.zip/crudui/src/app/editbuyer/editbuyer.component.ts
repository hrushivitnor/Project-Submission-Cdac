import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { BuyerserviceService } from '../buyerservice.service';
import { Buyers } from '../buyer';

@Component({
  selector: 'app-editbuyer',
  templateUrl: './editbuyer.component.html',
  styleUrls: ['./editbuyer.component.css']
})
export class EditbuyerComponent implements OnInit {
  bid: number;
  buyer: Buyers;
  constructor(private route: ActivatedRoute,private router: Router,
    private _service:BuyerserviceService) { }

  ngOnInit(): void {
    this.buyer = new Buyers();

    this.bid = this.route.snapshot.params['bid'];

    this._service.getBuyerById(this.bid)
      .subscribe(data => {
        console.log(data)
        this.buyer = data;
      },
       error => console.log(error));
  }



  updateBuyer() {
    this._service.updateBuyer(this.buyer)
      .subscribe(data => console.log(data), error => console.log(error));
    this.buyer = new Buyers();
    this.gotoList();
  }

  onSubmit() {
    this.updateBuyer();
  }

  gotoList() {
    this.router.navigate(['/buyers']);
  }

}
