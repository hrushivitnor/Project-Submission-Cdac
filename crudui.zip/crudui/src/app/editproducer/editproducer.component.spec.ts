import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditproducerComponent } from './editproducer.component';

describe('EditproducerComponent', () => {
  let component: EditproducerComponent;
  let fixture: ComponentFixture<EditproducerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditproducerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditproducerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
