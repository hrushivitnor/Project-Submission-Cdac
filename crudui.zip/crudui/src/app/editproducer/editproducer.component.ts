import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { ProducerserviceService } from '../producerservice.service';
import { Producer } from '../producer';


@Component({
  selector: 'app-editproducer',
  templateUrl: './editproducer.component.html',
  styleUrls: ['./editproducer.component.css']
})
export class EditproducerComponent implements OnInit {
  pid: number;
  buyer: Producer;
  producer: Producer;
  constructor(private route: ActivatedRoute,private router: Router,
    private _service:ProducerserviceService) { }

  ngOnInit(): void {
    this.producer= new Producer();

    this.pid = this.route.snapshot.params['pid'];

    this._service.getProducerById(this.pid)
      .subscribe(data => {
        console.log(data)
        this.producer = data;
      },
       error => console.log(error));
  }



  updateProducer() {
    this._service.updateProducer(this.producer)
      .subscribe(data => console.log(data), error => console.log(error));
    this.producer = new Producer();
    this.gotoList();
  }

  onSubmit() {
    this.updateProducer();
  }

  gotoList() {
    this.router.navigate(['/producers']);
  }

}

