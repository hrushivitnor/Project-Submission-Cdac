import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PownerComponent } from './powner.component';

describe('PownerComponent', () => {
  let component: PownerComponent;
  let fixture: ComponentFixture<PownerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PownerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PownerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
