import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-powner',
  templateUrl: './powner.component.html',
  styleUrls: ['./powner.component.css']
})
export class PownerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
