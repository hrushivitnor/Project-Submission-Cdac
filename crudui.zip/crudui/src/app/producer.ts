export class Producer {

    pid:number;

         pname:String ;

       emailId:String;

        address:String;
         district:String;
          city:String;

          pincode:number;
          state:String;

         contactNo:number;
           accountNo:number;

          aadharNo:number;
        licenceType:String;
        upin:number;
        cropPrice:number;
        cropname:string;

    
    }
