import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProducerlistComponent } from './producerlist.component';

describe('ProducerlistComponent', () => {
  let component: ProducerlistComponent;
  let fixture: ComponentFixture<ProducerlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProducerlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProducerlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
