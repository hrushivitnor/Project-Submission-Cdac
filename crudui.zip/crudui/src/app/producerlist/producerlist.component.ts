import { Component, OnInit } from '@angular/core';
import { Producer } from '../producer';
import { ProducerserviceService } from '../producerservice.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-producerlist',
  templateUrl:'./producerlist.component.html',
  styleUrls: ['./producerlist.component.css']
})
export class ProducerlistComponent implements OnInit {
  producer: Observable<Producer[]>;
  constructor(private _service:ProducerserviceService, private router: Router) { }

  ngOnInit(): void {
                        this.fetchProducerList();
                                                             
                       }
  

                       fetchProducerList() {
                        this.producer = this._service.getProducerList();
                      }


                      deleteProducer(pid: number) {
                        this._service.deleteProducer(pid)
                          .subscribe(
                            data => {
                              console.log(data);
                              this.fetchProducerList();
                            },
                            error => console.log(error));
                      }
                    
                    ProducerDetailsByID(pid: number) {
                        this.router.navigate(['viewproducer', pid]);
                      }
                    
                      updateProducer(buyer: Producer){
                        this.router.navigate(['update', Producer]);
                      }    
                      
                      CreateProducer()
                      {
                        this.router.navigate(['/addproducer']);
                      }
                    
}
