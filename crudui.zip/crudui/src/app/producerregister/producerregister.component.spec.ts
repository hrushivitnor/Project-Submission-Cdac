import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProducerregisterComponent } from './producerregister.component';

describe('ProducerregisterComponent', () => {
  let component: ProducerregisterComponent;
  let fixture: ComponentFixture<ProducerregisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProducerregisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProducerregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
