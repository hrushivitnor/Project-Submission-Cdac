import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-producerregister',
  templateUrl: './producerregister.component.html',
  styleUrls: ['./producerregister.component.css']
})
export class ProducerregisterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
