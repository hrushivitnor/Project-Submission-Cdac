import { TestBed } from '@angular/core/testing';

import { ProducerserviceService } from './producerservice.service';

describe('ProducerserviceService', () => {
  let service: ProducerserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProducerserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
