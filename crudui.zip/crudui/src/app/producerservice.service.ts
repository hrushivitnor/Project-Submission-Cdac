import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ProducerserviceService {
  private baseUrl = 'http://localhost:8081';
  constructor(private _http:HttpClient) { }



createProducer(producers: Object): Observable<Object> {
  return this._http.post(this.baseUrl+'/Producer/', producers);
}

updateProducer(producers: Object): Observable<Object> {
  return this._http.put(this.baseUrl+'/producers/', producers);
}

deleteProducer(pid: number): Observable<any> {
  return this._http.delete(this.baseUrl+'/producers/'+pid);
}

getProducerList(): Observable<any> {
  return this._http.get(this.baseUrl+'/producers/');
}
getProducerById(pid:number): Observable<any> {
  return this._http.get(this.baseUrl+'/producers/'+pid);
}
}
