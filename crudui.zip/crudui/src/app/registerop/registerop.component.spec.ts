import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisteropComponent } from './registerop.component';

describe('RegisteropComponent', () => {
  let component: RegisteropComponent;
  let fixture: ComponentFixture<RegisteropComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisteropComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisteropComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
