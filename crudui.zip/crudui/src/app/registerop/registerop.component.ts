import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registerop',
  templateUrl: './registerop.component.html',
  styleUrls: ['./registerop.component.css']
})
export class RegisteropComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
