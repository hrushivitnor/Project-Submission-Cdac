import { TestBed } from '@angular/core/testing';

import { UpdatebuyerService } from './updatebuyer.service';

describe('UpdatebuyerService', () => {
  let service: UpdatebuyerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UpdatebuyerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
