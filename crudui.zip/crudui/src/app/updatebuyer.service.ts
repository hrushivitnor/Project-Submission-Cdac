
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UpdatebuyerService {
  private baseUrl = 'http://localhost:4200';
  constructor(private _http:HttpClient) { }



createBuyer(buyers: Object): Observable<Object> {
  return this._http.post(this.baseUrl+'/buyers/', buyers);
}

updateBuyer(buyers: Object): Observable<Object> {
  return this._http.put(this.baseUrl+'/buyers/', buyers);
}

deleteBuyer(ubid: number): Observable<any> {
  return this._http.delete(this.baseUrl+'/buyers/'+ubid);
}

getBuyerList(): Observable<any> {
  return this._http.get(this.baseUrl+'/buyers/');
}
getBuyerById(ubid:number): Observable<any> {
  return this._http.get(this.baseUrl+'/buyers/'+ubid);
}
}
