import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { BuyerserviceService } from '../buyerservice.service';
import { Buyers } from '../buyer';


@Component({
  selector: 'app-updatebuyer',
  templateUrl: './updatebuyer.component.html',
  styleUrls: ['./updatebuyer.component.css']
})
export class UpdatebuyerComponent implements OnInit {
  ubid: number;
  cropPrice:number;
  cropname:String;
  buyer: Buyers;

  constructor(private route: ActivatedRoute,private router: Router,
    private _service:BuyerserviceService) { }

  ngOnInit(): void {
    this.buyer = new Buyers();

    this.ubid = this.route.snapshot.params['bid'];

    this._service.getBuyerById(this.ubid)
      .subscribe(data => {
        console.log(data)
        this.buyer = data;
      },
       error => console.log(error));
  }

  updateBuyer() {
    this._service.updateBuyer(this.buyer)
      .subscribe(data => console.log(data), error => console.log(error));
    this.buyer = new Buyers();
    this.gotoList();
  }

  onSubmit() {
    this.updateBuyer();
  }

  gotoList() {
    this.router.navigate(['/buyers']);
  }

}

