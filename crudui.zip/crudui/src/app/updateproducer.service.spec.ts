import { TestBed } from '@angular/core/testing';

import { UpdateproducerService } from './updateproducer.service';

describe('UpdateproducerService', () => {
  let service: UpdateproducerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UpdateproducerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
