import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UpdateproducerService {
  private baseUrl = 'http://localhost:8081';
  constructor(private _http:HttpClient) { }



createProducer(producer: Object): Observable<Object> {
  return this._http.post(this.baseUrl+'/producers/', producer);
}

updateProducer(producer: Object): Observable<Object> {
  return this._http.put(this.baseUrl+'/producers/', producer);
}

deleteProducer(upid: number): Observable<any> {
  return this._http.delete(this.baseUrl+'/producers/'+upid);
}

getProducerList(): Observable<any> {
  return this._http.get(this.baseUrl+'/producers/');
}
getProducerById(upid:number): Observable<any> {
  return this._http.get(this.baseUrl+'/producers/'+upid);
}
}

