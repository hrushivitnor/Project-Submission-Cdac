import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateproducerComponent } from './updateproducer.component';

describe('UpdateproducerComponent', () => {
  let component: UpdateproducerComponent;
  let fixture: ComponentFixture<UpdateproducerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateproducerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateproducerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
