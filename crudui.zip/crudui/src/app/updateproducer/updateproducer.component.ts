import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { ProducerserviceService } from '../producerservice.service';
import { Producer } from '../producer';

@Component({
  selector: 'app-updateproducer',
  templateUrl: './updateproducer.component.html',
  styleUrls: ['./updateproducer.component.css']
})
export class UpdateproducerComponent implements OnInit {
  upid: number;
  cropPrice:number;
  cropname:String;
  producer: Producer;

  constructor(private route: ActivatedRoute,private router: Router,
    private _service:ProducerserviceService) { }

  ngOnInit(): void {
    this.producer = new Producer();

    this.upid = this.route.snapshot.params['pid'];

    this._service.getProducerById(this.upid)
      .subscribe(data => {
        console.log(data)
        this.producer = data;
      },
       error => console.log(error));
  }

  updateProducer() {
    this._service.updateProducer(this.producer)
      .subscribe(data => console.log(data), error => console.log(error));
    this.producer = new Producer();
    this.gotoList();
  }

  onSubmit() {
    this.updateProducer();
  }

  gotoList() {
    this.router.navigate(['/producers']);
  }

}
