import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { Buyers } from '../buyer';
import { BuyerserviceService } from '../buyerservice.service';

@Component({
  selector: 'app-viewbuyer',
  templateUrl: './viewbuyer.component.html',
  styleUrls: ['./viewbuyer.component.css']
})
export class ViewbuyerComponent implements OnInit {
  bid: number;
  buyer: Buyers;

  constructor(private _service:BuyerserviceService,private router:Router,private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.buyer = new Buyers();

    this.bid = this.route.snapshot.params['bid'];

    this._service.getBuyerById(this.bid)
      .subscribe(data => {
        console.log(data);
        this.buyer = data;
        console.log(" data recived in view ");
      }, error => console.log(error));




  }

}
