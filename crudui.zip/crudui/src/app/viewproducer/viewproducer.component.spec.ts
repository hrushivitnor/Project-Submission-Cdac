import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewproducerComponent } from './viewproducer.component';

describe('ViewproducerComponent', () => {
  let component: ViewproducerComponent;
  let fixture: ComponentFixture<ViewproducerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewproducerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewproducerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
