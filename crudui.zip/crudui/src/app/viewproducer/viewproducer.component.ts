import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { Producer } from '../producer';
import { ProducerserviceService } from '../producerservice.service';

@Component({
  selector: 'app-viewproducer',
  templateUrl: './viewproducer.component.html',
  styleUrls: ['./viewproducer.component.css']
})
export class ViewproducerComponent implements OnInit {
  pid: number;
  producer: Producer;

  constructor(private _service:ProducerserviceService,private router:Router,private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.producer= new Producer();

    this.pid = this.route.snapshot.params['pid'];

    this._service.getProducerById(this.pid)
      .subscribe(data => {
        console.log(data);
        this.producer= data;
        console.log(" data recived in view ");
      }, error => console.log(error));




  }

}
